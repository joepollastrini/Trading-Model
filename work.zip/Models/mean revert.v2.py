'''
Mean Reversion Strategy
Use 2 SMA's and close price to determine large moves away from the average
Use RSI to determine when to enter the move towards mean and when to exit
To buy:
    1) fast sma < slow sma (switch?)
    2) close x * (boll band width) times below fast sma 
    3) RSI below 50 - y
    => Buy
    => Stop Loss at lower boll? z% from close
    => Exit when RSI > 50 + r

To sell:
    1) fast sma > slow sma (switch?)
    2) close x * (boll band width) above fast sma
    3) RSI above 50 + y
    => Sell
    => Stop Loss at upper boll? z% from close
    => Exit when RSI < 50 - r
'''

import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import myIndicators as mind
import model_analysis as ma
import matplotlib

## VARIABLES ##
DATAFOLDER = 'ETFs'#'Favs'
DATAPATH = os.path.join("C:\\"
                        ,"Users"
                        ,"joepo"
                        ,"Desktop"
                        ,"Back Testing"
                        ,"Data"
                        ,DATAFOLDER
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
TICKERLIST = rando.allTickers(DATAPATH)
FORCE_TICKER = None
STARTDATE, ENDDATE, NUMDAYS = rando.twoDates(
    DATAPATH, TICKERLIST[0], DATEDICT[ITERATOR])
print("Running backtest from {} to {}".format(STARTDATE, ENDDATE))
#TICKERLIST = ['ABT', 'ATVI']
STARTINGCASH = 10000
SIZINGPERC = 0.05
FAST_SMA = 20
SLOW_SMA = 100
BOLL_STD = 1
RANGE_DIST_MIN = 1.7
RANGE_DIST_MAX = 2.3
EXIT_DIST = 3.15
RESET_DIST = 1.15
RSI_THRESH = 20
RSI_CLOSE = 10
RSI_PERIOD = 14
## VARIABLES ##

cerebro = bt.Cerebro()
for t in TICKERLIST:
    data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, t + '.csv')
                                   ,fromdate = STARTDATE
                                   ,todate = ENDDATE
                                   ,nullvalue = 0.0
                                   ,dtformat = DATEDICT[ITERATOR]
                                   ,datetime = 0
                                   ,high = 2
                                   ,low = 3
                                   ,open = 1
                                   ,close = 4
                                   ,volume = 6
                                   ,openinterest = -1 #no open interest column
                                   )
    cerebro.adddata(data, name=t)
cerebro.broker.set_cash(STARTINGCASH)
cerebro.addstrategy(strats.SMA_RSI_MEAN_REVERT
                    ,sizingPerc = SIZINGPERC
                    ,fastSMA = FAST_SMA
                    ,slowSMA = SLOW_SMA
                    ,bollStd = BOLL_STD
                    ,rangeLow = RANGE_DIST_MIN
                    ,rangeHigh = RANGE_DIST_MAX
                    ,stopRange = EXIT_DIST
                    ,resetRange = RESET_DIST
                    ,rsiBound = RSI_THRESH
                    ,rsiClose = RSI_CLOSE
                    ,rsiPeriod = RSI_PERIOD
                    )
##add analyzers
cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
cerebro.addanalyzer(bt.analyzers.SQN, _name='sqn')
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
cerebro.addanalyzer(bt.analyzers.Returns, _name='annRets')
##run it all
test = cerebro.run()
analysis = test[0]
##get analyzers
sharpe = analysis.analyzers.sharpe.get_analysis()
sqn = analysis.analyzers.sqn.get_analysis()
rets = analysis.analyzers.annRets.get_analysis()
trade = analysis.analyzers.trades.get_analysis()
#print analysis
print(ma.main_analysis(sharpe, sqn, rets))
print(ma.trade_analysis(trade))
##print each model per ticker one at a time
for i in range(len(test[0].datas)):
    for j, d in enumerate(test[0].datas):
        d.plotinfo.plot = i == j
    cerebro.plot()

