#Model 1 - getting random data correct

from __future__ import (absolute_import, division, print_function, unicode_literals)
import backtrader as bt
import datetime
import os
import sys
import rando
import matplotlib

### VARIABLES ###
MAINPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(MAINPATH, DATEDICT, ITERATOR)
print("Running backtest for %s from %s to %s" % (TICKER, STARTDATE, ENDDATE))
STARTINGCASH = 10000
### VARIABLES ###

### HOLD STRATEGY ###
class LongHold(bt.Strategy):
    def __init__(self):
        self.dataclose = self.datas[0].close

    def sizingCalc(self, capital, price):
        shares = int(capital/price)
        return shares

    def next(self):
        if not self.position:
            numShares = self.sizingCalc(self.broker.getvalue(), self.dataclose)
            self.buy(size = numShares)
        else:
            pass

    def stop(self):
        pnl = self.broker.getvalue() - STARTINGCASH
        print("Ending Value: $%.2f\nP&L:  $%.2f" %
              (self.broker.getvalue()
               ,pnl)
              )
### HOLD STRATEGY ###

#get data
data = bt.feeds.GenericCSVData(dataname = os.path.join(MAINPATH, TICKER + '.csv')
                               ,fromdate = STARTDATE
                               ,todate = ENDDATE
                               ,nullvalue = 0.0
                               ,dtformat = DATEFORMAT
                               ,datetime = 0
                               ,high = 2
                               ,low = 3
                               ,open = 1
                               ,close = 4
                               ,volume = 6
                               ,openinterest = -1 #no open interest column
                               )
cerebroHold = bt.Cerebro()
cerebroHold.broker.set_cash(STARTINGCASH)
cerebroHold.adddata(data)
cerebroHold.addstrategy(LongHold)
cerebroHold.run()
cerebroHold.plot()

    

