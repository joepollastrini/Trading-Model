'''
Mean Reversion Strategy
Use 2 SMA's and close price to determine large moves away from the average
Use RSI to determine when to enter the move towards mean and when to exit
To buy:
    1) fast sma < slow sma (switch?)
    2) close x * (boll band width) times below fast sma 
    3) RSI below 50 - y
    => Buy
    => Stop Loss at lower boll? z% from close
    => Exit when RSI > 50 + r

To sell:
    1) fast sma > slow sma (switch?)
    2) close x * (boll band width) above fast sma
    3) RSI above 50 + y
    => Sell
    => Stop Loss at upper boll? z% from close
    => Exit when RSI < 50 - r
'''

from __future__ import (absolute_import, division, print_function, unicode_literals)
import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import myIndicators as mind
import model_analysis as ma
import matplotlib
import numpy as np

## VARIABLES ##
DATAPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
FORCE_TICKER = None
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(
    DATAPATH, DATEDICT, ITERATOR, FORCE_TICKER
    )
print("Running backtest from {} to {}".format(STARTDATE, ENDDATE))
TICKERLIST = ['ABT'
              ,'ATVI'
              ,'CSCO'
              ,'CVS'
              ,'LOW'
              ,'NKE'
              ,'SBUX'
              ,'T'
              ]
#TICKERLIST = ['ABT', 'ATVI']
STARTINGCASH = 10000
SIZINGPERC = 0.05
FAST_SMA = 20
SLOW_SMA = 100
BOLL_STD = 1
RANGE_DIST_MIN = 1.7
RANGE_DIST_MAX = 2.3
EXIT_DIST = 3.15
RESET_DIST = 1.15
RSI_THRESH = 20
RSI_CLOSE = 10
RSI_PERIOD = 14
DO_PRINT = False
## VARIABLES ##
cerebro = bt.Cerebro()
for t in TICKERLIST:
    data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, t + '.csv')
                                   ,fromdate = STARTDATE
                                   ,todate = ENDDATE
                                   ,nullvalue = 0.0
                                   ,dtformat = DATEFORMAT
                                   ,datetime = 0
                                   ,high = 2
                                   ,low = 3
                                   ,open = 1
                                   ,close = 4
                                   ,volume = 6
                                   ,openinterest = -1 #no open interest column
                                   )
    cerebro.adddata(data, name=t)
cerebro.broker.set_cash(STARTINGCASH)
opts = cerebro.optstrategy(strats.SMA_RSI_MEAN_REVERT
                    ,sizingPerc = np.arange(0.01, 0.1, 0.01)#SIZINGPERC
                    ,fastSMA = FAST_SMA
                    ,slowSMA = SLOW_SMA
                    ,bollStd = BOLL_STD
                    ,rangeLow = RANGE_DIST_MIN
                    ,rangeHigh = RANGE_DIST_MAX
                    ,stopRange = EXIT_DIST
                    ,resetRange = RESET_DIST
                    ,rsiBound = RSI_THRESH
                    ,rsiClose = RSI_CLOSE
                    ,rsiPeriod = RSI_PERIOD
                    ,printLog = DO_PRINT
                    )
##run it all
cerebro.run(maxcpus = 1)



