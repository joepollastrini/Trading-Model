import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import myIndicators as mind
import model_analysis as ma
import matplotlib
import time

## VARIABLES ##
TICKERLIST = {}
DATAFOLDER = 'Favs'
DATAPATH = os.path.join("C:\\"
                        ,"Users"
                        ,"joepo"
                        ,"Desktop"
                        ,"Back Testing"
                        ,"Data"
                        ,DATAFOLDER
                        )
TICKERLIST = rando.allTickers(DATAPATH)
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
FORCE_TICKER = 'ATVI'
STARTDATE, ENDDATE, NUMDAYS = rando.twoDates(
    DATAPATH, TICKERLIST[0], DATEDICT[ITERATOR])
print("Running backtest from {} to {}".format(STARTDATE, ENDDATE))
#TICKERLIST = ['ABT', 'ATVI']
#TICKERLIST = [FORCE_TICKER]
STARTINGCASH = 10000
SIZINGPERC = 0.025
RSI_THRESH = 20
RSI_RESET = 10
CMF_THRESH = 0
ADX_THRESH = 20
## VARIABLES ##

## STRATEGY ##
class ADX_TREND_CONFIRM(bt.Strategy):
    params = dict(
        sizingPerc = 0.01
        ,bollStd = 2.0
        ,bollPeriod = 14
        ,rsiBound = 25
        ,rsiPeriod = 14
        ,rsiReset = 10
        ,rsiExit = 15
        ,cmfBound = 0
        ,cmfExit = 0
        ,cmfPeriod = 21
        ,adxBound = 25
        ,adxPeriod = 14
        ,adxExit = 20
        ,printLog = True
        )

    def __init__(self):
        self.startCash = None
        self.order = {}
        self.stoploss = {}
        self.ls = {}
        self.highStop = {}
        self.lowStop = {}
        self.adxStart = {}
        self.rsiBelow = {}
        self.rsiAbove = {}
        self.inds = {}
        self.canLog = {}
        for i, d in enumerate(self.datas):
            self.order[d] = None
            self.stoploss[d] = None
            self.ls[d] = 0
            self.highStop[d] = 0
            self.lowStop[d] = 0
            self.adxStart[d] = False
            self.rsiBelow[d] = False
            self.rsiAbove[d] = False
            self.canLog[d] = False
            self.inds[d] = {}
            self.inds[d]['rsi'] = bt.ind.RSI_SMA(d.close, period = self.p.rsiPeriod)
            self.inds[d]['bands'] = bt.ind.BBands(d.close, period = self.p.bollPeriod, devfactor = self.p.bollStd, plot=False)
            self.inds[d]['cmf'] = mind.ChaikinMoneyFlow(d, period = self.p.cmfPeriod)
            self.inds[d]['adx'] = bt.ind.ADX(d, period = self.p.adxPeriod)
            #self.inds[d]['rsi buy'] = bt.ind.CrossDown(self.inds[d]['rsi'].lines.rsi, 50 - self.p.rsiBound, plot=False)
            #self.inds[d]['rsi sell'] = bt.ind.CrossUp(self.inds[d]['rsi'].lines.rsi, 50 + self.p.rsiBound, plot=False)
            
    def start(self):
        self.startCash = self.broker.getvalue()

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        if order.status in [order.Completed]:
            d = order.data
            if order.isbuy():
                bs = "Bought"
                self.ls[d] = 1
            else:
                bs = "Sold"
                self.ls[d] = -1
            self.log("{} {} shares of {} for ${:.2f}".format(
                bs
                ,order.executed.size
                ,d._name
                ,order.executed.price))
            self.order[d] = None
        elif order.status in [order.Canceled]:
            self.log('Order Canceled for {}'.format(order.data._name))
        elif order.status in [order.Margin, order.Rejected]:
            self.log('Order rejected or margin issue')

    def resetBools(self, t):
        self.ls[t] = 0
        self.adxStart[t] = False
        self.rsiBelow[t] = False
        self.rsiAbove[t] = False

    def notify_trade(self, trade):
        d = trade.data
        if not trade.isclosed:
            return
        self.log("P&L:  ${:.2f}".format(trade.pnlcomm))
        self.stoploss[d] = None
        self.resetBools(d)

    def log(self, txt, dp=False):
        if self.p.printLog or dp:
            date = self.datas[0].datetime.date(0)
            print("{}: {}".format(date, txt))

    def specialLog(self, txt, dp):
        if dp:
            date = self.datas[0].datetime.date(0)
            print("{}: {}".format(date, txt))

    def sizingCalc(self, capital, price):
        available = float(capital) * self.p.sizingPerc
        shares = round(available/price)
        return shares

    def next(self):
        self.rsi = {}
        self.mfi = {}
        self.adx = {}
        self.anyLog = False
        for i, d in enumerate(self.datas):
            self.rsi[d] = self.inds[d]['rsi'].lines.rsi[0]
            self.mfi[d] = self.inds[d]['cmf'].lines.mfi[0]
            self.adx[d] = self.inds[d]['adx'].lines.adx[0]
            #self.log(d._name)
            '''
            self.log('Close: ${:.2f}'.format(d.close[0]))
            self.log("RSI: {:.2f}".format(self.rsi[d]))
            self.log("MFI: {:.2f}".format(self.mfi[d]))
            self.log("ADX: {:.2f}".format(self.adx[d]))
            self.log('****************')
            '''
            ##make sure not in the market (no position)
            if self.getposition(d).size == 0:
                ##make sure no trend
                ##once no trend, trend ind. won't be set until trade made
                if self.adxStart[d] or self.adx[d] < 20.0:
                    self.adxStart[d] = True
                    ##check for RSI below threshold
                    if self.rsi[d] < 50 - self.p.rsiBound or self.rsiBelow[d]:
                        self.rsiBelow[d] = True
                        self.rsiAbove[d] = False
                        ##make sure RSI hasn't gone above the reset level
                        ##i.e. broke below, then broke back above before a trend could be identified
                        if self.rsi[d] > 50 - self.p.rsiReset:
                            #self.log('RSI reset')
                            self.rsiBelow[d] = False
                        if self.rsiBelow[d]:
                            #self.log('RSI below threshold')
                            if self.mfi[d] > 0:
                                #self.log('Money flow positive, look for a trend')
                                ##check if ADX is signaling a trend
                                if self.adx[d] > self.p.adxBound:
                                    numShares = self.sizingCalc(self.broker.getvalue(), d.close[0])
                                    self.order[d] = self.buy(data=d, size=numShares)
                                    self.log("Buy {} shares of {}".format(numShares, d._name))
                                    self.anyLog = True
                                    bandRange = abs(self.inds[d]['bands'].lines.mid[0] - self.inds[d]['bands'].lines.bot[0])
                                    self.lowStop[d] = d.close[0] - bandRange
                    ##check for RSI above threshold
                    elif self.rsi[d] > 50 + self.p.rsiBound or self.rsiAbove[d]:
                        self.rsiAbove[d] = True
                        self.rsiBelow[d] = False
                        ##make sure RSI hasn't gone below the reset level
                        ##i.e. broke above, then broke back below before a trend could be id'd
                        if self.rsi[d] < 50 + self.p.rsiReset:
                            #self.log('RSI reset')
                            self.rsiAbove[d] = False
                        if self.rsiAbove[d]:
                            #self.log('RSI above threshold')
                            if self.mfi[d] < 0:
                                #self.log('Money flow negative, look for a trend')
                                if self.adx[d] > self.p.adxBound:
                                    numShares = self.sizingCalc(self.broker.getvalue(), d.close[0])
                                    self.order[d] = self.sell(data=d, size=numShares)
                                    self.log("Sell {} shares of {}".format(numShares, d._name))
                                    self.anyLog = True
                                    bandRange = abs(self.inds[d]['bands'].lines.mid[0] - self.inds[d]['bands'].lines.bot[0])
                                    self.highStop[d] = d.close[0] + bandRange
            else:
                if self.ls[d] < 0: ##sold
                    ##check for exits
                    if self.adx[d] < self.p.adxExit:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                        self.log("ADX below {}, close position".format(self.p.adxExit))
                        self.anyLog = True
                    elif self.mfi[d] > self.p.cmfExit:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                        self.log("CMF above {}, close position".format(self.p.cmfExit))
                        self.anyLog = True
                    elif self.rsi[d] < 50 - self.p.rsiExit:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                        self.log("RSI below {}, take profit? and close".format(50 - self.p.rsiExit))
                        self.anyLog = True
                    if self.stoploss[d] is None and not self.order[d]:
                        ##no stop loss order and no order to exit
                        self.stoploss[d] = self.close(data=d, exectype=bt.Order.Stop, price=self.highStop[d])
                        self.log("Buy stop created at ${:.2f} for {}".format(self.highStop[d], d._name))
                        self.anyLog = True
                        
                else: ##bought
                    ##check for exits 
                    if self.adx[d] < self.p.adxExit:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                        self.log("ADX below {}, close position".format(self.p.adxExit))
                        self.anyLog = True
                    elif self.mfi[d] < self.p.cmfExit:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                        self.log("CMF below {}, close position".format(self.p.cmfExit))
                        self.anyLog = True
                    elif self.rsi[d] > 50 + self.p.rsiExit:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                        self.log("RSI above {}, take profit? and close".format(50 - self.p.rsiExit))
                        self.anyLog = True
                    if self.stoploss[d] is None and not self.order[d]:
                        self.stoploss[d] = self.close(data=d, exectype=bt.Order.Stop, price=self.lowStop[d])
                        self.log("Sell stop created at ${:.2f} for {}".format(self.lowStop[d], d._name))
                        self.anyLog = True
        self.specialLog('--------------------------------', self.anyLog)

    def stop(self):
        pnl = self.broker.getvalue() - self.startCash
        self.log("\n\n ------- Final Analysis ------- ")
        print("Ending Value: ${:.2f}\nP&L:  ${:.2f}\n".format(self.broker.getvalue(), pnl))
        

            
        
## STRATEGY ##
cerebro = bt.Cerebro()
for t in TICKERLIST:
    data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, t + '.csv')
                                   ,fromdate = STARTDATE
                                   ,todate = ENDDATE
                                   ,nullvalue = 0.0
                                   ,dtformat = DATEDICT[ITERATOR]
                                   ,datetime = 0
                                   ,high = 2
                                   ,low = 3
                                   ,open = 1
                                   ,close = 4
                                   ,volume = 6
                                   ,openinterest = -1 #no open interest column
                                   )
    cerebro.adddata(data, name=t)
cerebro.broker.set_cash(STARTINGCASH)

##add strategy
cerebro.addstrategy(ADX_TREND_CONFIRM
                    ,sizingPerc = SIZINGPERC
                    ,rsiBound = RSI_THRESH
                    ,cmfBound = CMF_THRESH
                    ,adxBound = ADX_THRESH
                    ,rsiReset = RSI_RESET
                    )

##add analyzers
cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
cerebro.addanalyzer(bt.analyzers.SQN, _name='sqn')
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
cerebro.addanalyzer(bt.analyzers.Returns, _name='annRets')
##run it all
test = cerebro.run()
analysis = test[0]
##get analyzers
sharpe = analysis.analyzers.sharpe.get_analysis()
sqn = analysis.analyzers.sqn.get_analysis()
rets = analysis.analyzers.annRets.get_analysis()
trade = analysis.analyzers.trades.get_analysis()
#print analysis
print(ma.main_analysis(sharpe, sqn, rets))
print(ma.trade_analysis(trade))
##print each model per ticker one at a time
for i in range(len(test[0].datas)):
    for j, d in enumerate(test[0].datas):
        d.plotinfo.plot = i == j
    cerebro.plot()
