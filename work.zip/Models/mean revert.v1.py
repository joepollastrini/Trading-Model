'''
Mean Reversion Strategy
Use 2 SMA's and close price to determine large moves away from the average
Use RSI to determine when to enter the move towards mean and when to exit
To buy:
    1) fast sma < slow sma (switch?)
    2) close x% below fast sma (ATR?)
    3) RSI below 50 - y
    => Buy
    => Stop Loss at lower boll? z% from close
    => Exit when RSI > 50 + r

To sell:
    1) fast sma > slow sma (switch?)
    2) close x% above fast sma (ATR?)
    3) RSI above 50 + y
    => Sell
    => Stop Loss at upper boll? z% from close
    => Exit when RSI < 50 - r
'''

import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import myIndicators as mind
import model_analysis as ma
import matplotlib

## VARIABLES ##
DATAPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
FORCE_TICKER = None
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(
    DATAPATH, DATEDICT, ITERATOR, FORCE_TICKER
    )
print("Running backtest from {} to {}".format(STARTDATE, ENDDATE))
TICKERLIST = ['ABT'
              ,'ATVI'
              ,'CSCO'
              ,'CVS'
              ,'LOW'
              ,'NKE'
              ,'SBUX'
              ,'T'
              ]
#TICKERLIST = ['ABT', 'ATVI']
STARTINGCASH = 10000
SIZINGPERC = 0.05
FAST_SMA = 20
SLOW_SMA = 100
RANGE_DIST = 0.08
RSI_THRESH = 15
EXIT_DIST = 0.05
RSI_CLOSE = 10
RSI_PERIOD = 14
FAR_RESET = 0.025
## VARIABLES ##


class SMA_RSI_MEAN_REVERT(bt.Strategy):
    params = dict(
        sizingPerc = 0.01
        ,fastSMA = 20
        ,slowSMA = 100
        ,tooFar = 0.2
        ,rsiBound = 20
        ,exitFar = 0.05
        ,rsiClose = 5
        ,rsiPeriod = 14
        ,resetFarInd = 0.05
        ,printLog = True
        )

    def __init__(self):
        self.startCash = None
        self.order = {}
        self.stoploss = {}
        self.fastSlow = {}
        self.smaCrosses = {}
        self.smaDist = {}
        self.distFar = {}
        self.distResetCheckShort = {}
        self.distResetCheckLong = {}
        self.distResetCheck = {}
        self.rsiCross = {}
        self.ls = {}
        self.highStop = {}
        self.lowStop = {}
        self.inds = {}
        for i, d in enumerate(self.datas):
            self.order[d] = None
            self.stoploss[d] = None
            self.fastSlow[d] = None
            self.smaCrosses[d] = 0
            self.smaDist[d] = 0
            self.distFar[d] = False
            self.distResetCheckShort[d] = False
            self.distResetCheckLong[d] = False
            self.rsiCross[d] = None
            self.ls[d] = 0
            self.highStop[d] = 0
            self.lowStop[d] = 0
            self.inds[d] = {}
            self.inds[d]['sma fast'] = bt.ind.SMA(d.close, period = self.p.fastSMA).lines.sma
            self.inds[d]['sma slow'] = bt.ind.SMA(d.close, period = self.p.slowSMA).lines.sma
            self.inds[d]['rsi'] = bt.ind.RSI_SMA(d.close, period = self.p.rsiPeriod)
            self.inds[d]['rsi buy'] = bt.ind.CrossDown(self.inds[d]['rsi'].lines.rsi, 50 - self.p.rsiBound, plot=False)
            self.inds[d]['rsi sell'] = bt.ind.CrossUp(self.inds[d]['rsi'].lines.rsi, 50 + self.p.rsiBound, plot=False)
            self.inds[d]['rsi close long'] = bt.ind.CrossUp(self.inds[d]['rsi'].lines.rsi, 50 + self.p.rsiClose, plot=False)
            self.inds[d]['rsi close short'] = bt.ind.CrossDown(self.inds[d]['rsi'].lines.rsi, 50 - self.p.rsiClose, plot=False)

    def start(self):
        self.startCash = self.broker.getvalue()

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        if order.status in [order.Completed]:
            d = order.data
            if order.isbuy():
                bs = "Bought"
                self.ls[d] = 1
            else:
                bs = "Sold"
                self.ls[d] = -1
            self.log("{} {} shares of {} for ${:.2f}".format(
                bs
                ,order.executed.size
                ,d._name
                ,order.executed.price))
        elif order.status in [order.Canceled]:
            self.log('Order Canceled for {}'.format(order.data._name))
        elif order.status in [order.Margin, order.Rejected]:
            self.log('Order rejected or margin issue')

    def resetBools(self, t):
        self.fastSlow[t] = None
        self.smaCrosses[t] = 0
        self.smaDist[t] = 0
        self.distFar[t] = False
        self.distResetCheckLong[t] = False
        self.distResetCheckShort[t] = False
        self.rsiCross[t] = None
        self.ls[t] = 0
    
    def notify_trade(self, trade):
        d = trade.data
        if not trade.isclosed:
            return
        self.log("P&L:  ${:.2f}".format(trade.pnlcomm))
        self.stoploss[d] = None
        self.resetBools(d)

    def log(self, txt):
        if self.p.printLog:
            date = self.datas[0].datetime.date(0)
            print("{}: {}".format(date, txt))

    def sizingCalc(self, capital, price):
        available = float(capital) * self.p.sizingPerc
        shares = round(available/price)
        return shares

    def awayThreshold(self, thresh, fast, close, ab):
        if ab == "Above":
            new = float(fast) * (1 + float(thresh))
            if float(close) > new:
                return True
            else:
                return False
        elif ab == "Below":
            new = float(fast) * (1 - float(thresh))
            if float(close) < new:
                return True
            else:
                return False
        else:
            self.log("awayThreshold:  We have a problem: {}".format(ab))

    def resetAway(self, reset, fast, close, ab):
        if ab == "Above":
            new = float(fast) * (1 + float(reset))
            if float(close) > new:
                return True
            else:
                return False
        elif ab == "Below":
            new = float(fast) * (1 - float(reset))
            if float(close) < new:
                return True
            else:
                return False

    def next(self):
        for i, d in enumerate(self.datas):
            self.log("{} : ${:.2f}".format(d._name, d.close[0]))
            if self.getposition(d).size == 0: ##not in market
                #self.log("No Current Position")
                if self.inds[d]['sma fast'] > self.inds[d]['sma slow']: ##fast above slow ma
                    #self.log("SMA Fast Above Slow")
                    self.fastSlow[d] = "Above"
                    if not self.distResetCheckShort[d]: ##False means start or have had to reset because of reversion.  Check for new distance away
                        self.distFar[d] = self.awayThreshold(self.p.tooFar, self.inds[d]['sma fast'][0], d.close[0], self.fastSlow[d])
                        self.distResetCheckShort[d] = True
                        self.distResetCheckLong[d] = False
                    else: ##True means got far enough away, check to make sure no reversion.
                        self.distFar[d] = self.awayThreshold(self.p.resetFarInd, self.inds[d]['sma fast'][0], d.close[0], self.fastSlow[d])
                    if self.distFar[d]: ##still far from sma, check for RSI entry
                        if self.inds[d]['rsi sell'].lines.cross[0] > 0:
                            numShares = self.sizingCalc(self.broker.getvalue(), d.close[0])
                            self.order[d] = self.sell(data=d, size = numShares)
                            self.log("Sell {} shares of {}".format(numShares, d._name))
                            self.highStop[d] = d.close[0] * (1 + self.p.exitFar)
                    else: ##not far enough from sma, reset check to check further distance
                        self.distResetCheckShort[d] = False                    

                elif self.inds[d]['sma fast'] < self.inds[d]['sma slow']: ##fast below slow sma
                    #self.log("SMA Fast Below Slow")
                    self.fastSlow[d] = "Below"
                    if not self.distResetCheckLong[d]: ##False means start or have had to reset because of reversion.  Check for new distance away
                        self.distFar[d] = self.awayThreshold(self.p.tooFar, self.inds[d]['sma fast'][0], d.close[0], self.fastSlow[d])
                        self.distResetCheckLong[d] = True
                        self.distResetCheckShort[d] = False
                    else: ##True means got far enough away, check to make sure no reversion
                        self.distFar[d] = self.awayThreshold(self.p.tooFar, self.inds[d]['sma fast'][0], d.close[0], self.fastSlow[d])
                    if self.distFar[d]: ##still far from sma, check for RSI entry
                        if self.inds[d]['rsi buy'].lines.cross[0] > 0:
                            numShares = self.sizingCalc(self.broker.getvalue(), d.close[0])
                            self.order[d] = self.buy(data=d, size = numShares)
                            self.log("Buy {} shares of {}".format(numShares, d._name))
                            self.lowStop[d] = d.close[0] * (1 - self.p.exitFar)
                    else: ##not far enough from sma, reset chack to check further distance
                        self.distResetCheckLong[d] = False
            else:
                if self.ls[d] < 0: ##sold
                    if self.stoploss[d] is None:
                        self.stoploss[d] = self.close(data=d
                                                      ,exectype=bt.Order.Stop
                                                      ,price=self.highStop[d]
                                                      )
                        self.log("Buy stop created at ${:.2f} for {}".format(
                            self.highStop[d], d._name))
                    ##check for rsi cross
                    if self.inds[d]['rsi close short'].lines.cross[0] > 0:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                        self.log("RSI broke below for {}, close position".format(d._name))
                    ##check for number of sma crosses #starts above
                    elif self.smaCrosses[d] == 0:
                        ##check for sma cross below
                        if self.inds[d]['sma fast'] < self.inds[d]['sma slow']:
                            self.smaCrosses[d] = 1
                    elif self.smaCrosses[d] == 1:
                        if self.inds[d]['sma fast'] > self.inds[d]['sma slow']:
                            ##sma crossed back above, exit short position
                            self.order[d] = self.close(data=d)
                            self.cancel(self.stoploss[d])
                            self.log("Upward momentum with SMA crossing up for {}, close position".format(d._name))
                else:  ##bought
                    if self.stoploss[d] is None:
                        self.stoploss[d] = self.close(data=d
                                                      ,exectype=bt.Order.Stop
                                                      ,price=self.lowStop[d]
                                                      )
                        self.log("Sell stop created at ${:.2f} for {}".format(
                            self.lowStop[d], d._name))

                    ##check for rsi cross
                    if self.inds[d]['rsi close long'].lines.cross[0] > 0:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                        self.log("RSI broke above for {}, close position".format(d._name))
                    elif self.smaCrosses[d] == 0:
                        ##check for sma cross above
                        if self.inds[d]['sma fast'] > self.inds[d]['sma slow']:
                            self.smaCrosses[d] = 1
                    elif self.smaCrosses[d] == 1:
                        if self.inds[d]['sma fast'] < self.inds[d]['sma slow']:
                            ##sma crossed back below, exit long position
                            self.order[d] = self.close(data=d)
                            self.cancel(self.stoploss[d])
                            self.log("Downard momentum with SMA crossing down for {}, close position".format(d._name))
        print(" ---------------------- ")                            
                        
                    

    def stop(self):
        pnl = self.broker.getvalue() - self.startCash
        print("\n\n ------- Final Analysis ------- ")
        print("Ending Value: ${:.2f}\nP&L:  ${:.2f}\n".format(self.broker.getvalue(), pnl))
        


cerebro = bt.Cerebro()
for t in TICKERLIST:
    data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, t + '.csv')
                                   ,fromdate = STARTDATE
                                   ,todate = ENDDATE
                                   ,nullvalue = 0.0
                                   ,dtformat = DATEFORMAT
                                   ,datetime = 0
                                   ,high = 2
                                   ,low = 3
                                   ,open = 1
                                   ,close = 4
                                   ,volume = 6
                                   ,openinterest = -1 #no open interest column
                                   )
    cerebro.adddata(data, name=t)
cerebro.broker.set_cash(STARTINGCASH)
cerebro.addstrategy(SMA_RSI_MEAN_REVERT
                    ,sizingPerc = SIZINGPERC
                    ,fastSMA = FAST_SMA
                    ,slowSMA = SLOW_SMA
                    ,tooFar = RANGE_DIST
                    ,rsiBound = RSI_THRESH
                    ,exitFar = EXIT_DIST
                    ,rsiClose = RSI_CLOSE
                    ,rsiPeriod = RSI_PERIOD
                    ,resetFarInd = FAR_RESET
                    )
test = cerebro.run()
for i in range(len(test[0].datas)):
    for j, d in enumerate(test[0].datas):
        d.plotinfo.plot = i == j
        
    cerebro.plot()

