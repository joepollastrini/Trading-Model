'''
First complicated model designed
Stepping stone to final model idea
Use bollinger band and RSI
To buy:
    1) close crosses above middle bollinger band
    2) RSI > 50
    3) Chaikin money flow > 0
    => Buy
    => Stop Loss at lower Bollinger
    => Exit when break below lower bolling, RSI < 50, or CMF < 0
To Sell:
    1) close crosses below middle bollinger
    2) RSI < 50
    3) Chaikin money flow < 0
    => Sell
    => Stop Loss at upper Bollinger
    => Exit when break abover upper bollinger, RSI > 50, or CMF > 0
'''

import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import myIndicators as mind
import model_analysis as ma
import matplotlib

### VARIABLES ###
DATAPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
FORCE_TICKER = None
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(
    DATAPATH, DATEDICT, ITERATOR, FORCE_TICKER
    )
print("Running backtest from {} to {}".format(STARTDATE, ENDDATE))
TICKERLIST = ['ABT'
              ,'ATVI'
              ,'CSCO'
              ,'CVS'
              ,'LOW'
              ,'NKE'
              ,'SBUX'
              ,'T'
              ]
TICKERLIST = ['ABT', 'ATVI']
STARTINGCASH = 10000
SIZINGPERC = 0.025
RSI_THRESH = 5
RSI_PERIOD = 14
BOLL_PERIOD = 20
BOLL_DEV = 2.0
RSI_SMA = True
CMF_PERIOD = 14
CMF_THRESH = 0.05
### VARIABLES ###

## STRATEGY ##
class BOLL_RSI_CMF(bt.Strategy):
    params = dict(
        sizingPerc = .01
        ,rsiThresh = 0
        ,printLog = True
        ,rsiPeriod = 14
        ,bollPeriod = 20
        ,bollDev = 2.0
        ,rsiType = True
        ,cmfPeriod = 14
        ,cmfThresh = 0
        )

    def __init__(self):
        self.startCash = None
        self.order = {}
        self.stoploss = {}
        self.aboveMid = {}
        self.belowMid = {}
        self.RSIup = {}
        self.RSIdown = {}
        self.CMFup = {}
        self.CMFdown = {}
        self.ls = {}
        self.highStop = {}
        self.lowStop = {}
        self.inds = {}
        for i, d in enumerate(self.datas):
            self.order[d] = None
            self.stoploss[d] = None
            self.aboveMid[d] = None
            self.belowMid[d] = None
            self.RSIup[d] = None
            self.RSIdown[d] = None
            self.CMFup[d] = None
            self.CMFdown[d] = None
            self.ls[d] = 0
            self.highStop[d] = 0.0
            self.lowStop[d] = 0.0
            self.inds[d] = {}
            if self.p.rsiType:
                self.inds[d]['RSI'] = bt.ind.RSI_SMA(d.close, period = self.p.rsiPeriod)
            else:
                self.inds[d]['RSI'] = bt.ind.RSI_EMA(d.close, period = self.p.rsiPeriod)
            self.inds[d]['Bands'] = bt.ind.BBands(d.close, period = self.p.bollPeriod, devfactor = self.p.bollDev)
            self.inds[d]['CMF'] = mind.ChaikinMoneyFlow(d, period = self.p.cmfPeriod)
            self.inds[d]['Boll Up'] = bt.ind.CrossUp(d.close, self.inds[d]['Bands'].lines.mid, plot=False)
            self.inds[d]['Boll Down'] = bt.ind.CrossDown(d.close, self.inds[d]['Bands'].lines.mid, plot=False)
            self.inds[d]['RSI Buy'] = bt.ind.CrossUp(self.inds[d]['RSI'].lines.rsi, 50 + self.p.rsiThresh, plot=False)
            self.inds[d]['RSI Sell'] = bt.ind.CrossDown(self.inds[d]['RSI'].lines.rsi, 50 - self.p.rsiThresh, plot=False)
            self.inds[d]['CMF Buy'] = bt.ind.CrossUp(self.inds[d]['CMF'].lines.mfi, 0 + self.p.cmfThresh, plot=False)
            self.inds[d]['CMF Sell'] = bt.ind.CrossDown(self.inds[d]['CMF'].lines.mfi, 0 - self.p.cmfThresh, plot=False)
            self.inds[d]['Bottom Cross'] = bt.ind.CrossDown(d.close, self.inds[d]['Bands'].lines.bot, plot=False)
            self.inds[d]['Top Cross'] = bt.ind.CrossUp(d.close, self.inds[d]['Bands'].lines.top, plot=False)
            self.inds[d]['RSI Close Long'] = bt.ind.CrossDown(self.inds[d]['RSI'].lines.rsi, 50, plot=False)
            self.inds[d]['RSI Close Short'] = bt.ind.CrossUp(self.inds[d]['RSI'].lines.rsi, 50, plot=False)
            self.inds[d]['CMF Close Long'] = bt.ind.CrossDown(self.inds[d]['CMF'].lines.mfi, 0, plot=False)
            self.inds[d]['CMF Close Short'] = bt.ind.CrossUp(self.inds[d]['CMF'].lines.mfi, 0, plot=False)

    def start(self):
        self.startCash = self.broker.getvalue()
    
    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        if order.status in [order.Completed]:
            d = order.data
            if order.isbuy():
                bs = "Bought"
                self.ls[d] = 1
            else:
                bs = "Sold"
                self.ls[d] = -1
            self.log("{} {} shares of {} for ${:.2f}".format(
                bs
                ,order.executed.size
                ,d._name
                ,order.executed.price))
        elif order.status in [order.Canceled]:
            self.log('Order Canceled for {}'.format(order.data._name))
        elif order.status in [order.Margin, order.Rejected]:
            self.log('Order rejected or margin issue')   
    
    def notify_trade(self, trade):
        d = trade.data
        if not trade.isclosed:
            return
        self.log("P&L:  ${:.2f}".format(trade.pnlcomm))
        self.stoploss[d] = None
        self.resetBools(d)

    def log(self, txt):
        if self.p.printLog:
            date = self.datas[0].datetime.date(0)
            print("{}: {}".format(date, txt))

    def sizingCalc(self, capital, price):
        available = float(capital) * self.p.sizingPerc
        shares = round(available/price)
        return shares

    def resetBools(self, t):
        self.belowMid[t] = False
        self.aboveMid[t] = False
        self.RSIup[t] = False
        self.RSIdown[t] = False
        self.CMFup[t] = False
        self.CMFdown[t] = False

    def next(self):
        for i, d in enumerate(self.datas):
            if self.getposition(d).size == 0:
                ##Check entry indicators
                if self.inds[d]['Boll Up'][0]:
                    #self.log("{} closed above middle band".format(d._name))
                    self.belowMid[d] = False
                    self.aboveMid[d] = True
                elif self.inds[d]['Boll Down'][0]:
                    #self.log("{} closed below middle band".format(d._name))
                    self.belowMid[d] = True
                    self.aboveMid[d] = False
                #else:
                    #self.log("{} did not cross Boll".format(d._name))
                if self.inds[d]['RSI Buy'][0]:
                    self.RSIup[d] = True
                    self.RSIdown[d] = False
                elif self.inds[d]['RSI Sell'][0]:
                    self.RSIup[d] = False
                    self.RSIdown[d] = True
                #else:
                    #self.log("{} did not cross RSI".format(d._name))
                if self.inds[d]['CMF Buy'][0]:
                    self.CMFup[d] = True
                    self.CMFdown[d] = False
                elif self.inds[d]['CMF Sell'][0]:
                    self.CMFup[d] = False
                    self.CMFdown[d] = True
                #else:
                    #self.log("{} did not cross CMF".format(d._name))
                ##if all indicators, buy/sell
                if self.aboveMid[d] and self.RSIup[d] and self.CMFup[d]:
                    numShares = self.sizingCalc(self.broker.getvalue(), d.close[0])
                    self.order[d] = self.buy(data=d, size=numShares)
                    self.log("Buy {} shares of {}".format(numShares, d._name))
                    self.lowStop[d] = self.inds[d]['Bands'].lines.bot[0]
                elif self.belowMid[d] and self.RSIdown[d] and self.CMFdown[d]:
                    numShares = self.sizingCalc(self.broker.getvalue(), d.close[0])
                    self.order[d] = self.sell(data=d, size=numShares)
                    self.log("Sell {} shares of {}".format(numShares, d._name))
                    self.highStop[d] = self.inds[d]['Bands'].lines.top[0]
            ##Exits
            else:
                if self.stoploss[d] is None:
                    if self.ls[d] > 0:
                        self.stoploss[d] = self.close(data=d
                                                      ,exectype=bt.Order.Stop
                                                      ,price = self.lowStop[d]
                                                      )
                        self.log("Sell stop created at ${:.2f} for {}".format(
                            self.lowStop[d], d._name))
                    else:
                        self.stoploss[d] = self.close(data=d
                                                      ,exectype=bt.Order.Stop
                                                      ,price = self.highStop[d]
                                                      )
                        self.log("Buy stop created at ${:.2f} for {}".format(
                            self.highStop[d], d._name))
                if self.ls[d] > 0 and self.inds[d]['Bottom Cross'][0]:
                    self.order[d] = self.close(data=d)
                    self.cancel(self.stoploss[d])
                    self.log("Lower band crossed for {}, close position".format(d._name))
                elif self.ls[d] > 0 and self.inds[d]['RSI Close Long'][0]:
                    self.order[d] = self.close(data=d)
                    self.cancel(self.stoploss[d])
                    self.log("RSI broke below for {}, close position".format(d._name))
                elif self.ls[d] > 0 and self.inds[d]['CMF Close Long'][0]:
                    self.order[d] = self.close(data=d)
                    self.cancel(self.stoploss[d])
                    self.log("CMF brok below for {}, close position".format(d._name))
                elif self.ls[d] < 0 and self.inds[d]['Top Cross'][0]:
                    self.order[d] = self.close(data=d)
                    self.cancel(self.stoploss[d])
                    self.log("Upper band crossed for {}, close position".format(d._name))
                elif self.ls[d] < 0 and self.inds[d]['RSI Close Short'][0]:
                    self.order[d] = self.close(data=d)
                    self.cancel(self.stoploss[d])
                    self.log("RSI broke above for {}, close position".format(d._name))
                elif self.ls[d] < 0 and self.inds[d]['CMF Close Short'][0]:
                    self.order[d] = self.close(data=d)
                    self.cancel(self.stoploss[d])
                    self.log("CMF broke above for {}, close position".format(d._name))
        self.log("\n")

    def stop(self):
        pnl = self.broker.getvalue() - self.startCash
        print("\n\n ------- Final Analysis ------- ")
        print("Ending Value: ${:.2f}\nP&L:  ${:.2f}\n".format(self.broker.getvalue(), pnl))
        


cerebro = bt.Cerebro()
for t in TICKERLIST:
    data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, t + '.csv')
                                   ,fromdate = STARTDATE
                                   ,todate = ENDDATE
                                   ,nullvalue = 0.0
                                   ,dtformat = DATEFORMAT
                                   ,datetime = 0
                                   ,high = 2
                                   ,low = 3
                                   ,open = 1
                                   ,close = 4
                                   ,volume = 6
                                   ,openinterest = -1 #no open interest column
                                   )
    cerebro.adddata(data, name=t)
cerebro.broker.set_cash(STARTINGCASH)

## add strategy
cerebro.addstrategy(BOLL_RSI_CMF
                    ,sizingPerc = SIZINGPERC
                    ,rsiThresh = RSI_THRESH
                    ,rsiPeriod = RSI_PERIOD
                    ,bollPeriod = BOLL_PERIOD
                    ,bollDev = BOLL_DEV
                    ,cmfPeriod = CMF_PERIOD)
##

#add analyzers
cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
cerebro.addanalyzer(bt.analyzers.SQN, _name='sqn')
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
cerebro.addanalyzer(bt.analyzers.Returns, _name='annRets')
#run backtest
test = cerebro.run()
analysis = test[0]
#get analyzers
sharpe = analysis.analyzers.sharpe.get_analysis()
sqn = analysis.analyzers.sqn.get_analysis()
rets = analysis.analyzers.annRets.get_analysis()
trade = analysis.analyzers.trades.get_analysis()
#print analysis
print(ma.main_analysis(sharpe, sqn, rets))
print(ma.trade_analysis(trade))
#plot
for i in range(len(test[0].datas)):
    for j, d in enumerate(test[0].datas):
        d.plotinfo.plot = i == j
        
    cerebro.plot()
