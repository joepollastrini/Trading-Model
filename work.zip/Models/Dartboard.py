'''
Designed to be a benchmark analysis
Somewhat simulates throwing a dart at a dartboard for decision making
Every day has x% probability of making trade
x% chance of buy vs sell

Run as monte carlo to determine returns based on LLN
'''

import backtrader as bt
import datetime
import os
import sys
import rando
import matplotlib
import random
import statistics
import matplotlib.pyplot as plt
import numpy as np


### VARIABLES ###
MAINPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(MAINPATH, DATEDICT, ITERATOR)
print("Running Monte Carlo Dartboard Simulation for %s from %s to %s" % (TICKER, STARTDATE, ENDDATE))
STARTINGCASH = 10000
SIZINGPERC = 0.01
pTRADE = 0.20
pBUY = 0.50
ITERATIONS = 1000
NUMBINS = max(25, int(ITERATIONS/5), 5)
### VARIABLES ###


### DARTBOARD STRATEGY ###
class Dartboard(bt.Strategy):
    params = dict(
        ptrade = pTRADE
        ,pbuy = pBUY
        ,sizingPerc = SIZINGPERC
        )

    def __init__(self):
        self.dataclose = self.datas[0].close

    def sizingCalc(self, capital, price):
        available = float(capital) * self.p.sizingPerc
        shares = round(available/price)
        return shares        

    def next(self):
        tradeBool = random.random()
        if not self.position:
            if tradeBool <= self.p.ptrade:
                buyBool = random.random()
                numShares = self.sizingCalc(self.broker.getvalue(), self.dataclose)
                if buyBool <= self.p.pbuy:
                    self.buy(size = numShares)
                else:
                    self.sell(size = numShares)
            else:
                pass
        else:
            if tradeBool <= self.p.ptrade:
                self.close()
### DARTBOARD STRATEGY ###

### MONTE CARLO SETUP FOR BACKTEST ###
def monteCarlo(data, iters, cash, strat):
    i = 0
    returnsList = []
    while i < iters:
        cerebro = bt.Cerebro()
        cerebro.broker.set_cash(cash)
        cerebro.adddata(data)
        cerebro.addstrategy(strat)
        cerebro.addanalyzer(bt.analyzers.Returns, _name='ReturnData')
        analysis = cerebro.run()
        returns = analysis[0]
        totRet = returns.analyzers.ReturnData.get_analysis()['rnorm100']
        returnsList.append(totRet)
        i = i + 1

    return returnsList
### MONTE CARLO SETUP FOR BACKTEST ###

### ITERATE BACKTESTS ###
myData = bt.feeds.GenericCSVData(dataname = os.path.join(MAINPATH, TICKER + '.csv')
                               ,fromdate = STARTDATE
                               ,todate = ENDDATE
                               ,nullvalue = 0.0
                               ,dtformat = DATEFORMAT
                               ,datetime = 0
                               ,high = 2
                               ,low = 3
                               ,open = 1
                               ,close = 4
                               ,volume = 6
                               ,openinterest = -1 #no open interest column
                               )
returns = monteCarlo(myData, ITERATIONS, STARTINGCASH, Dartboard)
### ITERATE BACKTESTS ###

### STATISTICAL DATA ###
avgRet = statistics.mean(returns)
sigmaRet = statistics.stdev(returns)
minRet = min(returns)
maxRet = max(returns)

print("Mu:  %.3f" % (avgRet) + "%")
print("Sigma:  %.2f" % (sigmaRet))
print("Max Gain:  %.3f" % (maxRet) + "%")
print("Max Loss:  %.3f" % (minRet) + "%")

plt.hist(returns, density=True, bins=NUMBINS)
plt.ylabel('Returns')
plt.xlabel('Data')
plt.show()
### STATISTICAL DATA ###
