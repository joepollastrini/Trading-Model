import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import myIndicators as mind
import model_analysis as ma
import matplotlib
import time

## VARIABLES ##
TICKERLIST = {}
DATAFOLDER = 'Favs'
DATAPATH = os.path.join("C:\\"
                        ,"Users"
                        ,"joepo"
                        ,"Desktop"
                        ,"Back Testing"
                        ,"Data"
                        ,DATAFOLDER
                        )
TICKERLIST = rando.allTickers(DATAPATH)
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
FORCE_TICKER = 'ATVI'
STARTDATE, ENDDATE, NUMDAYS = rando.twoDates(
    DATAPATH, TICKERLIST[0], DATEDICT[ITERATOR])
print("Running backtest from {} to {}".format(STARTDATE, ENDDATE))
#TICKERLIST = ['ABT', 'ATVI']
#TICKERLIST = [FORCE_TICKER]
STARTINGCASH = 10000
SIZINGPERC = 0.025
RSI_THRESH = 20
CMF_THRESH = 0
ADX_THRESH = 20
ENTER_LENGTH = 3
EXIT_LENGTH = 8
## VARIABLES ##

## STRATEGY ##
class TREND_DIR_CONFIRM(bt.Strategy):
    params = dict(
        sizingPerc = 0.01
        ,bollStd = 2.0
        ,bollPeriod = 14
        ,rsiBound = 25
        ,rsiPeriod = 14
        ,cmfBound = 0
        ,cmfPeriod = 21
        ,adxBound = 25
        ,adxPeriod = 14
        ,rsiBuy = [1, 2, 3]
        ,rsiSell = [2, 3, 4]
        ,rsiDouble = [1, 4]
        ,enterLen = 3
        ,rsiExit = 15
        ,cmfExit = 0
        ,adxExit = 20
        ,exitLen = 5
        ,profitTake = 0.1
        ,printLog = True
        )

    def __init__(self):
        self.startCash = None
        self.order = {}
        self.stoploss = {}
        self.ls = {}
        self.highStop = {}
        self.lowStop = {}
        self.inds = {}
        self.rsiDirect = {}
        self.mfiDirect = {}
        self.mfiBS = {}
        self.rsiBS = {}
        self.sizingMult = {}
        self.enterInfo = {}
        for i, d in enumerate(self.datas):
            self.order[d] = None
            self.stoploss[d] = None
            self.ls[d] = 0
            self.highStop[d] = 0
            self.lowStop[d] = 0
            self.rsiDirect[d] = 0
            self.mfiDirect[d] = 0
            self.mfiBS[d] = 0
            self.rsiBS[d] = 0
            self.sizingMult[d] = 1
            self.enterInfo[d] = {}
            self.inds[d] = {}
            self.inds[d]['adx'] = bt.ind.ADX(d, period = self.p.adxPeriod)
            self.inds[d]['rsi'] = bt.ind.RSI_SMA(d.close, period = self.p.rsiPeriod)
            self.inds[d]['cmf'] = mind.ChaikinMoneyFlow(d, period = self.p.cmfPeriod)
            self.inds[d]['bands'] = bt.ind.BBands(d.close, period = self.p.bollPeriod, devfactor = self.p.bollStd, plot=False)

    def start(self):
        self.startCash = self.broker.getvalue()

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        if order.status in [order.Completed]:
            d = order.data
            if order.isbuy():
                bs = "Bought"
                self.ls[d] = 1
            else:
                bs = "Sold"
                self.ls[d] = -1
            self.log("{} {} shares of {} for ${:.2f}".format(
                bs
                ,order.executed.size
                ,d._name
                ,order.executed.price))
            self.order[d] = None
            self.enterInfo[d]['price'] = order.executed.price
        elif order.status in [order.Canceled]:
            self.log('Order Canceled for {}'.format(order.data._name))
        elif order.status in [order.Margin, order.Rejected]:
            self.log('Order rejected or margin issue')

    def resetBools(self, t):
        self.ls[t] = 0
        self.rsiDirect[t] = 0
        self.mfiDirect[t] = 0
        self.mfiBS[t] = 0
        self.rsiBS[t] = 0
        self.sizingMult[t] = 1
        self.enterInfo[t] = {}

    def notify_trade(self, trade):
        d = trade.data
        if not trade.isclosed:
            return
        self.log("P&L:  ${:.2f}".format(trade.pnlcomm))
        self.stoploss[d] = None
        self.resetBools(d)

    def log(self, txt, dp=False):
        if self.p.printLog or dp:
            date = self.datas[0].datetime.date(0)
            print("{}: {}".format(date, txt))

    def sizingCalc(self, capital, price, mult):
        available = float(capital) * self.p.sizingPerc * mult
        shares = round(available/price)
        return shares

    def rsiLevel(self, rsi):
        if rsi < 50 - self.p.rsiBound:
            return 1
        elif rsi >= 50 - self.p.rsiBound and rsi < 50:
            return 2
        elif rsi >= 50 and rsi < 50 + self.p.rsiBound:
            return 3
        else:
            return 4

    def direction(self, lst):
        ##returns 0 if no trend
        ##returns 1 if bullish trend
        ## returns -1 if bearish trend
        lenth = len(lst)
        direct = []
        for i, l in enumerate(lst):
            ##don't check last entry, will throw error
            if i == lenth - 1:
                pass
            else:
                ##most recent higher than last
                if lst[i] > lst[i + 1]:
                    direct.append(1)
                ##most recent lower than last
                else:
                    direct.append(-1)
        #check if all items in direct are same
        agree = all(l == direct[0] for l in direct)
        if agree:
            return direct[0]
        else:
            return 0

    def next(self):
        self.adx = {}
        self.mfi = {}
        self.rsi = {}
        self.anyLog = False
        for i, d in enumerate(self.datas):
            #self.log(d._name)
            self.rsi[d] = []
            self.mfi[d] = []
            for i in range(0, self.p.enterLen * -1, -1):
                self.rsi[d].append(self.inds[d]['rsi'].lines.rsi[i])
                self.mfi[d].append(self.inds[d]['cmf'].lines.mfi[i])
            self.adx[d] = self.inds[d]['adx'].lines.adx[0]
            ##check for position
            if self.getposition(d).size == 0:
                ##check for trend
                #self.log(self.adx[d])
                if self.adx[d] > self.p.adxBound:
                    ##get direction agreement
                    #self.log(self.rsi[d])
                    self.rsiDirect[d] = self.direction(self.rsi[d])
                    #self.log(self.rsiDirect[d])
                    #self.log(self.mfi[d])
                    self.mfiDirect[d] = self.direction(self.mfi[d])
                    #self.log(self.mfiDirect[d])
                    ##get mfi buy/sell signal
                    if self.mfi[d][0] > 0 + self.p.cmfBound:
                        self.mfiBS[d] = 1
                    elif self.mfi[d][0] < 0 - self.p.cmfBound:
                        self.mfiBS[d] = -1
                    #self.log(self.mfiBS[d])
                    ##get rsi buy/sell signal
                    level = self.rsiLevel(self.rsi[d][0])
                    #self.log(level)
                    if level in self.p.rsiBuy:
                        self.rsiBS[d] = 1
                    elif level in self.p.rsiSell:
                        self.rsiBS[d] = -1
                    if level in self.p.rsiDouble:
                        self.sizingMult[d] = 2
                    #self.log(self.rsiBS[d])
                    ##check for signal agreement
                    self.signals = [self.rsiDirect[d], self.rsiBS[d], self.mfiDirect[d], self.mfiBS[d]]
                    #self.log(self.signals)
                    agree = all(l == self.signals[0] for l in self.signals)
                    if agree and self.signals[0] != 0:
                        if self.signals[0] == 1:
                            numShares = self.sizingCalc(self.broker.getvalue(), d.close[0], self.sizingMult[d])
                            self.order[d] = self.buy(data = d, size = numShares)
                            self.log("Buy {} shares of {}".format(numShares, d._name))
                            bandRange = abs(self.inds[d]['bands'].lines.mid[0] - self.inds[d]['bands'].lines.bot[0])
                            self.lowStop[d] = d.close[0] - bandRange
                            self.enterInfo[d]['rsi'] = self.rsi[d][0]
                            self.enterInfo[d]['cmf'] = self.mfi[d][0]
                            self.enterInfo[d]['adx'] = self.adx[d]
                            self.enterInfo[d]['zone'] = level
                        else:
                            numShares = self.sizingCalc(self.broker.getvalue(), d.close[0], self.sizingMult[d])
                            self.order[d] = self.sell(data = d, size = numShares)
                            self.log("Sell {} shares of {}".format(numShares, d._name))
                            bandRange = abs(self.inds[d]['bands'].lines.mid[0] - self.inds[d]['bands'].lines.bot[0])
                            self.highStop[d] = d.close[0] + bandRange
                            self.enterInfo[d]['rsi'] = self.rsi[d][0]
                            self.enterInfo[d]['cmf'] = self.mfi[d][0]
                            self.enterInfo[d]['adx'] = self.adx[d]
                            self.enterInfo[d]['zone'] = level
                    #else:
                        #self.log('Not all signals in agreement')
            else:
                close = False
                self.rsi[d] = []
                self.mfi[d] = []
                self.adx[d] = []
                for i in range(0, self.p.exitLen * -1, -1):
                    self.rsi[d].append(self.inds[d]['rsi'].lines.rsi[i])
                    self.mfi[d].append(self.inds[d]['cmf'].lines.mfi[i])
                    self.adx[d].append(self.inds[d]['adx'].lines.adx[i])
                #self.log(self.enterInfo[d])
                if self.ls[d] < 0: ##sold
                    ##check for exits
                    ##rsi breaks above zone + x
                    if self.inds[d]['rsi'].lines.rsi[0] > self.enterInfo[d]['rsi'] + self.p.rsiExit:
                        self.log('RSI moved against too far, close {}'.format(d._name))
                        close = True
                    ##cmf breaks above 0
                    elif self.inds[d]['cmf'].lines.mfi[0] > 0 + self.p.cmfExit:
                        self.log('CMF moved against, close {}'.format(d._name))
                        close = True
                    ##adx breaks below 20
                    elif self.inds[d]['adx'].lines.adx[0] < self.p.adxExit:
                        self.log('ADX too low, close {}'.format(d._name))
                        close = True
                    ##cmf x straight days of up
                    elif self.direction(self.mfi[d]) == 1:
                        self.log('CMF increased {} straight days, close {}'.format(self.p.exitLen, d._name))
                        close = True
                    ##rsi x straight days of up
                    elif self.direction(self.rsi[d]) == 1:
                        self.log('RSI increased {} straight days, close {}'.format(self.p.exitLen, d._name))
                        close = True
                    ##adx x straight days of down
                    #elif self.direction(self.adx[d]) == -1:
                    #    self.log('ADX decreased {} straight days, close {}'.format(self.p.exitLen, d._name))
                    #    close = True
                    ##profit take
                    elif d.close[0] <= self.enterInfo[d]['price'] * (1 - self.p.profitTake):
                        self.log('10% profit, take and close {}'.format(d._name))
                        close = True
                    ##adx above + x
                    elif self.inds[d]['adx'].lines.adx[0] >= self.enterInfo[d]['adx'] + self.p.adxExit:
                        self.log('ADX much higher than entered, likely profit, close {}'.format(d._name))
                        close = True
                    ##rsi in zone 1
                    elif self.rsiLevel(self.inds[d]['rsi'].lines.rsi[0]) == 1 and self.enterInfo[d]['zone'] != 2:
                        self.log('RSI fallen to oversold, close {}'.format(d._name))
                        close = True
                    if close == True:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                    if self.stoploss[d] is None and not self.order[d]:
                        ##no stop loss order and no exit order from above
                        self.stoploss[d] = self.close(data=d, exectype=bt.Order.Stop, price=self.highStop[d])
                        self.log("Buy stop created at ${:.2f} for {}".format(self.highStop[d], d._name))
                else:  ##bot
                    ##check for exits
                    ##rsi breaks below zone - x
                    if self.inds[d]['rsi'].lines.rsi[0] < self.enterInfo[d]['rsi'] - self.p.rsiExit:
                        self.log('RSI moved against too far, close {}'.format(d._name))
                        close = True
                    ##cmf breaks below 0
                    elif self.inds[d]['cmf'].lines.mfi[0] < 0 - self.p.cmfExit:
                        self.log('CMF moved against, close {}'.format(d._name))
                        close = True
                    ##adx breaks below 20
                    elif self.inds[d]['adx'].lines.adx[0] < self.p.adxExit:
                        self.log('ADX too low, close {}'.format(d._name))
                        close = True
                    ##cmf x straight days of down
                    elif self.direction(self.mfi[d]) == -1:
                        self.log('CMF decreased {} straight days, close {}'.format(self.p.exitLen, d._name))
                        close = True
                    ##rsi x straight days of down
                    elif self.direction(self.rsi[d]) == -1:
                        self.log('RSI decreased {} straight days, close {}'.format(self.p.exitLen, d._name))
                        close = True
                    ##adx x straight days of down
                    #elif self.direction(self.adx[d]) == -1:
                    #    self.log('ADX decreased {} straight days, close {}'.format(self.p.exitLen, d._name))
                    #    close = True
                    ##profit take
                    elif d.close[0] >= self.enterInfo[d]['price'] * (1 + self.p.profitTake):
                        self.log('10% profit, take and close {}'.format(d._name))
                        close = True
                    ##adx above + x
                    elif self.inds[d]['adx'].lines.adx[0] >= self.enterInfo[d]['adx'] + self.p.adxExit:
                        self.log('ADX much higher than entered, likely profit, close {}'.format(d._name))
                        close = True
                    ##rsi in zone 4
                    elif self.rsiLevel(self.inds[d]['rsi'].lines.rsi[0]) == 4 and self.enterInfo[d]['zone'] != 3:
                        self.log('RSI risen to overbought, close {}'.format(d._name))
                        close = True
                    if close == True:
                        self.order[d] = self.close(data=d)
                        self.cancel(self.stoploss[d])
                    if self.stoploss[d] is None and not self.order[d]:
                        self.stoploss[d] = self.close(data=d, exectype=bt.Order.Stop, price=self.lowStop[d])
                        self.log("Sell stop created at ${:.2f} for {}".format(self.lowStop[d], d._name))
        self.log('------------------')

    def stop(self):
        pnl = self.broker.getvalue() - self.startCash
        self.log("\n\n ------- Final Analysis ------- ")
        print("Ending Value: ${:.2f}\nP&L:  ${:.2f}\n".format(self.broker.getvalue(), pnl))



## STRATEGY ##

    
cerebro = bt.Cerebro()
for t in TICKERLIST:
    data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, t + '.csv')
                                   ,fromdate = STARTDATE
                                   ,todate = ENDDATE
                                   ,nullvalue = 0.0
                                   ,dtformat = DATEDICT[ITERATOR]
                                   ,datetime = 0
                                   ,high = 2
                                   ,low = 3
                                   ,open = 1
                                   ,close = 4
                                   ,volume = 6
                                   ,openinterest = -1 #no open interest column
                                   )
    cerebro.adddata(data, name=t)
cerebro.broker.set_cash(STARTINGCASH)

##add strategy
cerebro.addstrategy(TREND_DIR_CONFIRM
                    ,sizingPerc = SIZINGPERC
                    ,rsiBound = RSI_THRESH
                    ,cmfBound = CMF_THRESH
                    ,adxBound = ADX_THRESH
                    ,enterLen = ENTER_LENGTH
                    ,exitLen = EXIT_LENGTH
                    )

##add analyzers
cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
cerebro.addanalyzer(bt.analyzers.SQN, _name='sqn')
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
cerebro.addanalyzer(bt.analyzers.Returns, _name='annRets')
##run it all
test = cerebro.run()
analysis = test[0]
##get analyzers
sharpe = analysis.analyzers.sharpe.get_analysis()
sqn = analysis.analyzers.sqn.get_analysis()
rets = analysis.analyzers.annRets.get_analysis()
trade = analysis.analyzers.trades.get_analysis()
#print analysis
print(ma.main_analysis(sharpe, sqn, rets))
print(ma.trade_analysis(trade))
##print each model per ticker one at a time
for i in range(len(test[0].datas)):
    for j, d in enumerate(test[0].datas):
        d.plotinfo.plot = i == j
    cerebro.plot()
