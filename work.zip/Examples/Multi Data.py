#Testing and putthing together

from __future__ import (absolute_import, division, print_function, unicode_literals)
import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import model_analysis as ma
import matplotlib
import pprint

### VARIABLES ###
DATAPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(DATAPATH, DATEDICT, ITERATOR)
print("Running backtest from %s to %s" % (STARTDATE, ENDDATE))
STARTINGCASH = 10000
SIZINGPERC = 0.025
TRAILPERC = 0.05
TICKERLIST = ['ABT', 'LOW']
### VARIABLES ###

### BASIC STRATEGY ###
class SmaCross(bt.Strategy):
    #list of parameters which are configurable for the strategy
    params = dict(
        pfast = 10 # period for the fast moving average
        ,pslow = 30  # period for the slow moving average
        ,sizingPerc = .01
        ,trailPerc = .025
        ,printLog = True
        )

    def __init__(self):
        self.startCash = None
        self.order = {}
        self.stoploss = {}
        self.buyPrice = {}
        self.inds = {}
        self.dates = {}
        for i, d in enumerate(self.datas):
            #self.date[d] = d.datetime.date(0)
            self.order[d] = None
            self.stoploss[d] = None
            self.buyPrice[d] = None
            self.inds[d] = {}
            self.inds[d]['sma1'] = bt.ind.SMA(d.close, period = self.p.pfast)
            self.inds[d]['sma2'] = bt.ind.SMA(d.close, period = self.p.pslow)
            self.inds[d]['cross'] = bt.ind.CrossOver(self.inds[d]['sma1'], self.inds[d]['sma2'])

    def start(self):
        self.startCash = self.broker.getvalue()

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        if order.status in [order.Completed]:
            d = order.data
            if order.isbuy():
                self.log("Bought {} shares of {} for ${:.2f} ".format(
                    order.executed.size
                    ,d._name
                    ,order.executed.price))
                self.buyPrice[d] = order.executed.price
            elif order.issell():
                self.log("Sold {} shares of {} at ${:.2f}".format(
                    order.executed.size
                    ,d._name
                    ,order.executed.price))
                self.buyPrice[d] = None
        elif order.status in [order.Canceled]:
            self.log('Order Canceled')
        elif order.status in [order.Margin, order.Rejected]:
            self.log('Order rejected or margin issue')

    def notify_trade(self, trade):
        d = trade.data
        if not trade.isclosed:
            return
        self.log("P&L:  ${:.2f}".format(trade.pnlcomm))
        self.stoploss[d] = None
        

    def log(self, txt):
        if self.p.printLog:
            #date = self.dates[d]
            date = self.datas[0].datetime.date(0)
            print("{}: {}".format(date, txt))

    def sizingCalc(self, capital, price):
        available = float(capital) * self.p.sizingPerc
        shares = round(available/price)
        return shares

    def next(self):
        for i, d in enumerate(self.datas):
            if self.getposition(d).size == 0: ##not in market
                if self.inds[d]['cross'][0] > 0:
                    numShares = self.sizingCalc(self.broker.getvalue(), d.close[0])
                    self.order[d] = self.buy(data=d, size=numShares)
                    self.log("Buy {} shares of {}".format(
                        numShares, d._name))
            elif self.inds[d]['cross'][0] < 0:
                self.order[d] = self.close(data=d)
                self.log("Close position")
                self.cancel(self.stoploss[d])
            elif self.stoploss[d] is None:
                stopLoss = self.buyPrice[d] * (1.0 - self.p.trailPerc)
                self.stoploss[d] = self.close(data=d
                                              ,exectype=bt.Order.Stop
                                              ,price = stopLoss
                                              )
                self.log("Sell stop created at {:.2f}".format(stopLoss))

    def stop(self):
        pnl = self.broker.getvalue() - self.startCash
        print("\n\n ------- Final Analysis ------- ")
        print("Ending Value: ${:.2f}\nP&L:  ${:.2f}\n".format(self.broker.getvalue(), pnl))
        
### BASIC STRATEGY ###

#get data
cerebro = bt.Cerebro()
for t in TICKERLIST:
    data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, t + '.csv')
                               ,fromdate = STARTDATE
                               ,todate = ENDDATE
                               ,nullvalue = 0.0
                               ,dtformat = DATEFORMAT
                               ,datetime = 0
                               ,high = 2
                               ,low = 3
                               ,open = 1
                               ,close = 4
                               ,volume = 6
                               ,openinterest = -1 #no open interest column
                               )
    cerebro.adddata(data, name=t)
cerebro.broker.set_cash(STARTINGCASH)
cerebro.addstrategy(SmaCross, sizingPerc=SIZINGPERC, trailPerc = TRAILPERC) #add trading strategy
cerebro.run()
cerebro.plot()

    

