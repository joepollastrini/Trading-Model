import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import model_analysis as ma
import matplotlib

### VARIABLES ###
DATAPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
FORCE_TICKER = None
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(
    DATAPATH, DATEDICT, ITERATOR, FORCE_TICKER
    )
print("Running backtest for {} from {} to {}".format(
    TICKER, STARTDATE, ENDDATE
    ))
STARTINGCASH = 10000
SIZINGPERC = 0.025
TRAILPERC = 0.05
### VARIABLES ###

#get data
data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, TICKER + '.csv')
                               ,fromdate = STARTDATE
                               ,todate = ENDDATE
                               ,nullvalue = 0.0
                               ,dtformat = DATEFORMAT
                               ,datetime = 0
                               ,high = 2
                               ,low = 3
                               ,open = 1
                               ,close = 4
                               ,volume = 6
                               ,openinterest = -1 #no open interest column
                               )
cerebro = bt.Cerebro()
cerebro.broker.set_cash(STARTINGCASH)
cerebro.adddata(data)
cerebro.addstrategy(strats._strategy_name
                    ,_param1 = p1
                    ,_param2 = p2
                    )
#add analyzers
cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
cerebro.addanalyzer(bt.analyzers.SQN, _name='sqn')
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
cerebro.addanalyzer(bt.analyzers.Returns, _name='annRets')
#run backtest
test = cerebro.run()
analysis = test[0]
#get analyzers
sharpe = analysis.analyzers.sharpe.get_analysis()
sqn = analysis.analyzers.sqn.get_analysis()
rets = analysis.analyzers.annRets.get_analysis()
trade = analysis.analyzers.trades.get_analysis()
#print analysis
print(ma.main_analysis(sharpe, sqn, rets))
print(ma.trade_analysis(trade))
#plot
cerebro.plot()
