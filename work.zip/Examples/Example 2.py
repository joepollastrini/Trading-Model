from datetime import datetime
import backtrader as bt
import matplotlib
import os
import backtrader.analyzers as btanalyzers

class SmaCross(bt.Strategy):
    #list of parameters which are configurable for the strategy
    params = dict(
        pfast = 10, # period for the fast moving average
        pslow = 30  # period for the slow moving average
        )

    def __init__(self):
        sma1 = bt.ind.SMA(period = self.p.pfast)
        sma2 = bt.ind.SMA(period = self.p.pslow)
        self.crossover = bt.ind.CrossOver(sma1, sma2) #crossover signal

    def next(self):
        if not self.position: # not in market
            if self.crossover > 0:  # fast crosses slow to the upside
                self.buy()  # enter long position

        elif self.crossover < 0: # in market and crosses to downside
            self.close()  # close long position

cerebro = bt.Cerebro()  #create brains of whole operation

data = bt.feeds.GenericCSVData(dataname = os.path.join("C:\\", "Users", "joepo", "Desktop", "Back Testing", "AAPL.csv")
                               ,fromdate = datetime(2016, 1, 1)
                               ,todate = datetime(2019, 5, 31)
                               ,nullvalue = 0.0
                               ,dtformat = '%Y-%m-%d' #format CSV file dates are in
                               ,datetime = 0
                               ,high = 2
                               ,low = 3
                               ,open = 1
                               ,close = 4
                               ,volume = 6
                               ,openinterest = -1#no open interest column present
                               #,reverse = True
                               ) #tell function what columns are which

cerebro.adddata(data)  # add data to feed
cerebro.addstrategy(SmaCross) #add trading strategy
cerebro.addanalyzer(btanalyzers.SharpeRatio, _name='mysharpe')
thestrats = cerebro.run()
thestrat = thestrats[0]
print('Sharpe Ratio:', thestrat.analyzers.mysharpe.get_analysis())
#cerebro.plot()

