#https://www.backtrader.com/docu/quickstart/quickstart/

from __future__ import (absolute_import, division, print_function, unicode_literals)
import backtrader as bt
import datetime
import os.path
import sys

#mainpath = os.path.join("C:\\", "Users", "joepo", "Desktop", "Back Testing")

class MyCSV(bt.feeds.GenericCSVData):
    params = (
        ('nullvalue', 0.0),
        ('dtformat', ('%Y-%m-%d')),
        ('datetime', 0),
        ('high', 2),
        ('low', 3),
        ('open', 1),
        ('close', 4),
        ('volume', 6),
        ('openinterest', -1),
        ('reverse', True)
        )

class TestStrategy(bt.Strategy):
    params = (
        ('maperiod', 15),
        ('printlog', False),
        )
    
    def log(self, txt, dt=None, doprint=False):
        #logging function
        if self.params.printlog or doprint:
            dt = dt or self.datas[0].datetime.date(0)
            print('%s, %s' % (dt.isoformat(), txt))

    def __init__(self):
        #keep reference to clsoe line in data
        self.dataclose = self.datas[0].close
        #keeps track of pending orders
        self.order = None
        self.buyprice = None
        self.buycomm = None

        #add moving average indicator
        self.sma = bt.indicators.SimpleMovingAverage(
            self.datas[0], period = self.params.maperiod)

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            #buy/sell order submitted/accepted to/by broker - nothing to do
            return

        #check if order is completed
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log('BUY EXECUTED, Price: %.2f, Cost: %.2f, Comm: %.2f' %
                         (order.executed.price
                         ,order.executed.value
                         ,order.executed.comm))
                self.buyprice = order.executed.price
                self.buycomm = order.executed.comm
            else:
                #sell
                self.log('SELL EXECUTED, Price: %.2f, Cost: %.2f, Comm: %.2f' %
                         (order.executed.price
                          ,order.executed.value
                          ,order.executed.comm))
            self.bar_executed = len(self)

        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log('Order Canceled/Margin/Rejected')

        #write down: no pending order
        self.order = None

    def notify_trade(self, trade):
        if not trade.isclosed:
            return
        self.log('OPERATION PROFIT, GROSS %.2f, NET %.2f' % (trade.pnl, trade.pnlcomm))

    def next(self):
        #log closing price
        self.log('Close, %.2f' % self.dataclose[0])

        #check for pending order, won't send another if true
        if self.order:
            return

        #check if currently in market/hold a position
        if not self.position:
            #not in market, check trading parameters
            
            if self.dataclose[0] > self.sma[0]:
                #close higher than SMA
                self.log('BUY!!, %.2f' % self.dataclose[0])
                self.order = self.buy()

        else:
            #in market, check to see if we want to sell
            if self.dataclose[0] < self.sma[0]:
                #sell
                self.log('SELL CREATE, %.2f' % self.dataclose[0])

                #keep track of created order to avoid a 2nd order
                self.order = self.sell()

    def stop(self):
        self.log('(MA Period %2d) Ending Value %.2f' %
                 (self.params.maperiod, self.broker.getvalue()), doprint=True)

        

if __name__ == '__main__':
    #create cerebro instance
    cerebro = bt.Cerebro()

    #add strategy
    #optimizes strategy, does some test runs for all?
    strats = cerebro.optstrategy(
        TestStrategy,
        maperiod=range(10, 31))
    #cerebro.addstrategy(TestStrategy)

    #get data
    data = bt.feeds.GenericCSVData(dataname = os.path.join("C:\\", "Users", "joepo", "Desktop", "Back Testing","Data", "ABT.csv")
                                   ,fromdate = datetime.datetime(2016, 1, 1)
                                   ,todate = datetime.datetime(2017, 1, 1)
                                   ,nullvalue = 0.0
                                   ,dtformat = '%Y-%m-%d' #format CSV file dates are in
                                   ,datetime = 0
                                   ,high = 2
                                   ,low = 3
                                   ,open = 1
                                   ,close = 4
                                   ,volume = 6
                                   ,openinterest = -1#no open interest column present
                                   #,reverse = True
                                   ) #tell function what columns are which
    cerebro.adddata(data)

    #broker information
    cerebro.broker.setcash(1000.0) #set starting cash amount
    cerebro.broker.setcommission(commission = 0.0)  #0.001 implies a 0.1% fee per every trade
    cerebro.addsizer(bt.sizers.FixedSize, stake = 10) #add a fixed sizer according to the stake
                             
    
    print('Starting Portfolio Value: %.2f' % cerebro.broker.getvalue())
    cerebro.run(maxcpus = 1)
    print('Final Portfolio Value: %.2f' % cerebro.broker.getvalue())
    #cerebro.plot()
    
