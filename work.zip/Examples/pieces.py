#Testing and putthing together

from __future__ import (absolute_import, division, print_function, unicode_literals)
import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import model_analysis as ma
import matplotlib
import pprint

### VARIABLES ###
DATAPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(DATAPATH, DATEDICT, ITERATOR)
print("Running backtest for %s from %s to %s" % (TICKER, STARTDATE, ENDDATE))
STARTINGCASH = 10000
SIZINGPERC = 0.025
TRAILPERC = 0.05
### VARIABLES ###

### BASIC STRATEGY ###
class SmaCross(bt.Strategy):
    #list of parameters which are configurable for the strategy
    params = dict(
        pfast = 10 # period for the fast moving average
        ,pslow = 30  # period for the slow moving average
        ,sizingPerc = .01
        ,trailPerc = .025
        ,printLog = True
        )

    def __init__(self):
        self.dataclose = self.datas[0].close
        self.order = None
        self.stoploss = None
        self.buyPrice = None
        self.startCash = None
        sma1 = bt.ind.SMA(period = self.p.pfast)
        sma2 = bt.ind.SMA(period = self.p.pslow)
        self.crossover = bt.ind.CrossOver(sma1, sma2) #crossover signal

    def start(self):
        self.startCash = self.broker.getvalue()

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log("Paid ${:.2f} on {}".format(order.executed.price, order.executed.size))
                self.buyPrice = order.executed.price
            elif order.issell():
                self.log("Sold {} at ${:.2f}".format(order.executed.size, order.executed.price))
                self.buyPrice = None
        elif order.status in [order.Canceled]:
            self.log('Order Canceled')
        elif order.status in [order.Margin, order.Rejected]:
            self.log('Order rejected or margin issue')
        self.order = None

    def notify_trade(self, trade):
        if not trade.isclosed:
            return
        self.log("P&L:  ${:.2f}".format(trade.pnlcomm))
        self.cancel(self.stoploss)
        self.stoploss = None

    def log(self, txt):
        if self.p.printLog:
            date = self.datas[0].datetime.date(0)
            print("{}: {}".format(date, txt))
        

    def sizingCalc(self, capital, price):
        available = float(capital) * self.p.sizingPerc
        shares = round(available/price)
        return shares

    def next(self):
        if not self.position: # not in market
            if self.crossover > 0:  # fast crosses slow to the upside
                numShares = self.sizingCalc(self.broker.getvalue(), self.dataclose[0])
                self.order = self.buy(size = numShares)  # enter long position
                self.log("Buy {} shares".format(numShares))
        elif self.crossover < 0: # in market and crosses to downside
                self.order = self.close()  # close long position
                self.log("Close Position")
                self.cancel(self.stoploss)
        elif self.stoploss is None:
            stopLoss = self.buyPrice * (1.0 - self.p.trailPerc)
            self.stoploss = self.close(exectype = bt.Order.Stop
                                    ,price = stopLoss
                                    )
            self.log("Trailing stop created at {:.2f}".format(stopLoss))
            

    def stop(self):
        pnl = self.broker.getvalue() - self.startCash
        print("\n\n ------- Final Analysis ------- ")
        print("Ending Value: ${:.2f}\nP&L:  ${:.2f}\n".format(self.broker.getvalue(), pnl))
        
### BASIC STRATEGY ###

#get data
data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, TICKER + '.csv')
                               ,fromdate = STARTDATE
                               ,todate = ENDDATE
                               ,nullvalue = 0.0
                               ,dtformat = DATEFORMAT
                               ,datetime = 0
                               ,high = 2
                               ,low = 3
                               ,open = 1
                               ,close = 4
                               ,volume = 6
                               ,openinterest = -1 #no open interest column
                               )
cerebro = bt.Cerebro()
cerebro.broker.set_cash(STARTINGCASH)
cerebro.adddata(data)
cerebro.addstrategy(SmaCross, sizingPerc=SIZINGPERC, trailPerc = TRAILPERC) #add trading strategy
### ANALYZERS ###
cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
cerebro.addanalyzer(bt.analyzers.SQN, _name='sqn')
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
cerebro.addanalyzer(bt.analyzers.Returns, _name='annRets')
### ANALYZERS ###
test = cerebro.run()
analysis = test[0]


#get analyzers
sharpe = analysis.analyzers.sharpe.get_analysis()
sqn = analysis.analyzers.sqn.get_analysis()
rets = analysis.analyzers.annRets.get_analysis()
trade = analysis.analyzers.trades.get_analysis()

#print analysis
print(ma.main_analysis(sharpe, sqn, rets))
print(ma.trade_analysis(trade))

'''
#trade analyzer
totalClosed = analysis.analyzers.trades.get_analysis()['total']['closed']
winStreak = analysis.analyzers.trades.get_analysis()['streak']['won']['longest']
lossStreak = analysis.analyzers.trades.get_analysis()['streak']['lost']['longest']
pnl = analysis.analyzers.trades.get_analysis()['pnl']['net']['total']
avgPNL = analysis.analyzers.trades.get_analysis()['pnl']['net']['average']

wins = analysis.analyzers.trades.get_analysis()['won']['total']
pnlWins = analysis.analyzers.trades.get_analysis()['won']['pnl']['total']
pnlMaxGain = analysis.analyzers.trades.get_analysis()['won']['pnl']['max']
try:
    pnlWinAvg = float(pnlWins)/float(wins)
except ZeroDivisionError:
    pnlWinAvg = "N/A"
losses = analysis.analyzers.trades.get_analysis()['lost']['total']
pnlLosses = analysis.analyzers.trades.get_analysis()['lost']['pnl']['total']
pnlMaxLoss = analysis.analyzers.trades.get_analysis()['lost']['pnl']['max']
try:
    pnlLossAvg = float(pnlLosses)/float(losses)
except ZeroDivisionError:
    pnlLossAvg = "N/A"

longWins = analysis.analyzers.trades.get_analysis()['long']['won']
longLosses = analysis.analyzers.trades.get_analysis()['long']['lost']
longWinPNL = analysis.analyzers.trades.get_analysis()['long']['pnl']['won']['total']
longLossPNL = analysis.analyzers.trades.get_analysis()['long']['pnl']['lost']['total']
long = int(longWins) + int(longLosses)
try:
    longWinAvg = float(longWinPNL)/float(longWins)
except ZeroDivisionError:
    longWinAvg = "N/A"
try:
    longLossAvg = float(longLossPNL)/float(longLosses)
except ZeroDivisionError:
    longLossAvg = "N/A"
longPNL = float(longWinPNL) + float(longLossPNL)

shortWins = analysis.analyzers.trades.get_analysis()['short']['won']
shortLosses = analysis.analyzers.trades.get_analysis()['short']['lost']
shortWinPNL = analysis.analyzers.trades.get_analysis()['short']['pnl']['won']['total']
shortLossPNL = analysis.analyzers.trades.get_analysis()['short']['pnl']['lost']['total']
short = str(int(shortWins) + int(shortLosses))
try:
    shortWinAvg = float(shortWinPNL)/float(shortWins)
except ZeroDivisionError:
    shortWinAvg = "N/A"
try:
    shortLossAvg = float(shortLossPNL)/float(shortLosses)
except ZeroDivisionError:
    shortLossAvg = "N/A"
shortPNL = float(shortWinPNL) + float(shortLossPNL)

avgHold = analysis.analyzers.trades.get_analysis()['len']['average']
winAvgHold = analysis.analyzers.trades.get_analysis()['len']['won']['average']
lossAvgHold = analysis.analyzers.trades.get_analysis()['len']['lost']['average']
try:
    winPct = float(wins)/float(losses)
except ZeroDivisionError:
    winPct = "100"


print("\n\n ------ Trade Breakdowns ------ ")
print("Total Data\nP&L:  ${:.2f}\nAvg. P&L:  ${:.2f}\nWin Rate:  {:.2f}%".format(pnl, avgPNL, winPct))
print("\nWin Data\nAvg. Win:  ${:.2f}\nAvg Len:  {:.1f}\nMax Gain:  ${:.2f}".format(pnlWinAvg, winAvgHold, pnlMaxGain))
print("\nLoss Data\nAvg. Loss:  ${:.2f}\nAvg Len:  {:.1f}\nMax Loss:  ${:.2f}".format(pnlLossAvg, lossAvgHold, pnlMaxLoss))
print(" ------------------------------ ")
'''

#cerebro.plot()

    

