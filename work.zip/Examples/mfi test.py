import os
SUPP_PATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Supplemental"
                        )
import sys
sys.path.insert(1, SUPP_PATH)
import backtrader as bt
import datetime
import rando
import strats
import myIndicators as mind
import model_analysis as ma
import matplotlib
DATAPATH = os.path.join("C:\\"
                      ,"Users"
                      ,"joepo"
                      ,"Desktop"
                      ,"Back Testing"
                      ,"Data"
                        )
DATEDICT = {'d':'%Y-%m-%d'}
ITERATOR = 'd'
TICKER, STARTDATE, ENDDATE, DATEFORMAT, NUMDAYS = rando.main(DATAPATH, DATEDICT, ITERATOR, "ABT")
print("Running backtest for %s from %s to %s" % (TICKER, STARTDATE, ENDDATE))
STARTINGCASH = 10000
SIZINGPERC = 0.025
TRAILPERC = 0.05


class mfi(bt.Strategy):
    params = dict(period = 14)

    def __init__(self):
        for i, d in enumerate(self.datas):
            self.dataclose = self.datas[0].close     
            self.mf = mind.MoneyFlow(d)
            self.cmf = mind.ChaikinMoneyFlow(d)

    def log(self, txt):
        date = self.datas[0].datetime.date(0)
        print("{}: {}".format(date, txt))

    def next(self):
        pass
        #self.log(self.cmf.lines.mfi[0])
        #self.log(self.mf.lines.mfi[0])

cerebro = bt.Cerebro()
data = bt.feeds.GenericCSVData(dataname = os.path.join(DATAPATH, TICKER + '.csv')
                               ,fromdate = STARTDATE
                               ,todate = ENDDATE
                               ,nullvalue = 0.0
                               ,dtformat = DATEFORMAT
                               ,datetime = 0
                               ,high = 2
                               ,low = 3
                               ,open = 1
                               ,close = 4
                               ,volume = 6
                               ,openinterest = -1 #no open interest column
                               )
cerebro.adddata(data)
cerebro.addstrategy(mfi)
cerebro.run()
cerebro.plot()
